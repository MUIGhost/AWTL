// Function to handle form submission for adding a task
const addTaskForm = document.getElementById('add-task-form');
if (addTaskForm) {
    addTaskForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        const formData = new FormData(addTaskForm);
        const taskData = {};
        formData.forEach((value, key) => {
            taskData[key] = value;
        });

        try {
            const response = await fetch('/tasks', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(taskData)
            });

            if (!response.ok) {
                throw new Error('Failed to add task');
            }

            const data = await response.json();
            console.log('Task added successfully:', data);

            // Redirect or display success message
        } catch (error) {
            console.error('Error adding task:', error);
            // Display error message
        }
    });
}

// Function to fetch and display task details
const displayTaskDetails = async (taskId) => {
    try {
        const response = await fetch(`/tasks/${taskId}`);
        const data = await response.json();

        // Update DOM with task details
        console.log('Task details:', data);
    } catch (error) {
        console.error('Error fetching task details:', error);
        // Display error message
    }
};

// Call function to display task details if needed
const taskDetailsElement = document.getElementById('task-details');
if (taskDetailsElement) {
    const taskId = // Extract task ID from URL or other source
    displayTaskDetails(taskId);
}
