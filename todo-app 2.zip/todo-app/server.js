const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// MySQL connection configuration
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'task'
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// Route to handle task creation
app.post('/public', (req, res) => {
  const { task } = req.body;

  // Insert task into MySQL database
  const sql = 'INSERT INTO tasks (task) VALUES (?)';
  connection.query(sql, [task], (err, result) => {
    if (err) {
      console.error('Error creating task:', err);
      res.status(500).json({ success: false, message: 'Error creating task' });
    } else {
      res.status(200).json({ success: true, message: 'Task created successfully' });
    }
  });
});

// Route to handle task retrieval
app.get('/tasks', (req, res) => {
  // Retrieve tasks from MySQL database
  const sql = 'SELECT * FROM tasks';
  connection.query(sql, (err, rows) => {
    if (err) {
      console.error('Error retrieving tasks:', err);
      res.status(500).json({ success: false, message: 'Error retrieving tasks' });
    } else {
      res.status(200).json(rows);
    }
  });
});

// Route to handle task update
app.put('/tasks/:id', (req, res) => {
  const { id } = req.params;
  const { task } = req.body;

  // Update task in MySQL database
  const sql = 'UPDATE tasks SET task = ? WHERE id = ?';
  connection.query(sql, [task, id], (err, result) => {
    if (err) {
      console.error('Error updating task:', err);
      res.status(500).json({ success: false, message: 'Error updating task' });
    } else {
      res.status(200).json({ success: true, message: 'Task updated successfully' });
    }
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
