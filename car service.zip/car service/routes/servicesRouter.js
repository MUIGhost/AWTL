const express = require('express');
const services = require('../models/services'); // Assuming models folder is created

const router = express.Router();

// Routes for services (similar to carsRouter.js)

router.get('/', async (req, res) => {
  try {
    const allServices = await services.getServices(); // Implement getServices in services.js
    res.json(allServices);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching services');
  }
});

router.get('/:serviceId', async (req, res) => {
  const serviceId = req.params.serviceId;
  try {
    const service = await services.getServiceById(serviceId); // Implement getServiceById in services.js
    if (service) {
      res.json(service);
    } else {
      res.status(404).send('Service not found');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching service');
  }
});

router.post('/', async (req, res) => {
  const newService = req.body;
  try {
    const serviceId = await services.createService(newService); // Implement createService in services.js
    res.status(201).json({ message: `Service created with ID: ${serviceId}` });
  } catch (err) {
    console.error(err);
    res.status(400).send('Error creating service');
  }
});

router.put('/:serviceId', async (req, res) => {
  const serviceId = req.params.serviceId;
  const serviceData = req.body;
  try {
    await services.updateService(serviceId, serviceData); // Implement updateService in services.js
    res.json({ message: `Service with ID ${serviceId} updated` });
  } catch (err) {
    console.error(err);
    res.status(400).send('Error updating service');
  }
});

router.delete('/:serviceId', async (req, res) => {
  const serviceId = req.params.serviceId;
  try {
    await services.deleteService(serviceId); // Implement deleteService in services.js
    res.json({ message: `Service with ID ${serviceId} deleted` });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting service');
  }
});

module.exports = router;
