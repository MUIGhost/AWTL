const express = require('express');
const bookings = require('../models/bookings');

const router = express.Router();

// Routes for bookings
router.get('/', async (req, res) => {
  try {
    const allBookings = await bookings.getBookings();
    res.json(allBookings);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching bookings');
  }
});

router.get('/:bookingId', async (req, res) => {
  const bookingId = req.params.bookingId;
  try {
    const booking = await bookings.getBookingById(bookingId);
    if (booking) {
      res.json(booking);
    } else {
      res.status(404).send('Booking not found');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching booking');
  }
});

router.post('/', async (req, res) => {
  const newBooking = req.body;
  try {
    const bookingId = await bookings.createBooking(newBooking);
    res.status(201).json({ message: `Booking created with ID: ${bookingId}` });
  } catch (err) {
    console.error(err);
    res.status(400).send('Error creating booking');
  }
});

router.put('/:bookingId', async (req, res) => {
  const bookingId = req.params.bookingId;
  const bookingData = req.body;
  try {
    await bookings.updateBooking(bookingId, bookingData);
    res.json({ message: `Booking with ID ${bookingId} updated` });
  } catch (err) {
    console.error(err);
    res.status(400).send('Error updating booking');
  }
});

router.delete('/:bookingId', async (req, res) => {
  const bookingId = req.params.serviceId; // typo corrected to bookingId
  try {
    await bookings.deleteBooking(bookingId);
    res.json({ message: `Booking with ID ${bookingId} deleted` });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting booking');
  }
});

module.exports = router;
