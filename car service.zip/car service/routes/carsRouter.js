const express = require('express');
const cars = require('../models/cars'); // Assuming models folder is created

const router = express.Router();

// Get all cars
router.get('/', async (req, res) => {
  try {
    const allCars = await cars.getCars();
    res.json(allCars);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching cars');
  }
});

// Get a car by ID
router.get('/:carId', async (req, res) => {
  const carId = req.params.carId;
  try {
    const car = await cars.getCarById(carId);
    if (car) {
      res.json(car);
    } else {
      res.status(404).send('Car not found');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching car');
  }
});

// Create a new car
router.post('/', async (req, res) => {
  const newCar = req.body;
  try {
    const carId = await cars.createCar(newCar);
    res.status(201).json({ message: `Car created with ID: ${carId}` });
  } catch (err) {
    console.error(err);
    res.status(400).send('Error creating car');
  }
});

// Update a car
router.put('/:carId', async (req, res) => {
  const carId = req.params.carId;
  const carData = req.body;
  try {
    await cars.updateCar(carId, carData);
    res.json({ message: `Car with ID ${carId} updated` });
  } catch (err) {
    console.error(err);
    res.status(400).send('Error updating car');
  }
});

// Delete a car
router.delete('/:carId', async (req, res) => {
  const carId = req.params.carId;
  try {
    await cars.deleteCar(carId);
    res.json({ message: `Car with ID ${carId} deleted` });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting car');
  }
});

module.exports = router;
