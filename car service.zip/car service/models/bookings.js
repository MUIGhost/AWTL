const connection = require('../db');

async function getBookings() {
  const [rows] = await connection.query(`
    SELECT b.*, c.name AS customer_name, car.make, car.model, ser.name AS service_name
    FROM Bookings b
    INNER JOIN Customers c ON b.customer_id = c.customer_id
    INNER JOIN Cars car ON b.car_id = car.car_id
    INNER JOIN Services ser ON b.service_id = ser.service_id
  `);
  return rows;
}

async function getBookingById(bookingId) {
  const [rows] = await connection.query(`
    SELECT b.*, c.name AS customer_name, car.make, car.model, ser.name AS service_name
    FROM Bookings b
    INNER JOIN Customers c ON b.customer_id = c.customer_id
    INNER JOIN Cars car ON b.car_id = car.car_id
    INNER JOIN Services ser ON b.service_id = ser.service_id
    WHERE b.booking_id = ?
  `, [bookingId]);
  return rows[0];
}

async function createBooking(bookingData) {
  const [result] = await connection.query('INSERT INTO Bookings SET ?', bookingData);
  return result.insertId;
}

async function updateBooking(bookingId, bookingData) {
  await connection.query('UPDATE Bookings SET ? WHERE booking_id = ?', [bookingData, bookingId]);
}

async function deleteBooking(bookingId) {
  await connection.query('DELETE FROM Bookings WHERE booking_id = ?', [bookingId]);
}

module.exports = { getBookings, getBookingById, createBooking, updateBooking, deleteBooking };
