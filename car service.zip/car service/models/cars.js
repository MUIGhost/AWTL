const connection = require('../db.js');

async function getCars() {
  const [rows] = await connection.query('SELECT * FROM Cars');
  return rows;
}

async function getCarById(carId) {
  const [rows] = await connection.query('SELECT * FROM Cars WHERE car_id = ?', [carId]);
  return rows[0];
}

async function createCar(carData) {
  const [result] = await connection.query('INSERT INTO Cars SET ?', carData);
  return result.insertId;
}

async function updateCar(carId, carData) {
  await connection.query('UPDATE Cars SET ? WHERE car_id = ?', [carData, carId]);
}

async function deleteCar(carId) {
  await connection.query('DELETE FROM Cars WHERE car_id = ?', [carId]);
}

module.exports = { getCars, getCarById, createCar, updateCar, deleteCar };
