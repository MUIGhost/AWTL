const connection = require('../db');

async function getServices() {
  const [rows] = await connection.query('SELECT * FROM Services');
  return rows;
}

async function getServiceById(serviceId) {
  const [rows] = await connection.query('SELECT * FROM Services WHERE service_id = ?', [serviceId]);
  return rows[0];
}

async function createService(serviceData) {
  const [result] = await connection.query('INSERT INTO Services SET ?', serviceData);
  return result.insertId;
}

async function updateService(serviceId, serviceData) {
  await connection.query('UPDATE Services SET ? WHERE service_id = ?', [serviceData, serviceId]);
}

async function deleteService(serviceId) {
  await connection.query('DELETE FROM Services WHERE service_id = ?', [serviceId]);
}

module.exports = { getServices, getServiceById, createService, updateService, deleteService };
