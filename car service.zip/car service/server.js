const express = require('express');
const carsRouter = require('./routes/carsRouter'); // Assuming routes folder is created
const servicesRouter = require('./routes/servicesRouter'); // Assuming routes folder is created
const bookingsRouter = require('./routes/bookingsRouter'); // Assuming routes folder is created
const mysql = require('mysql2/promise');

const connection = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'car_service_management' // Replace with your database name
});
const app = express();

// Middleware to parse incoming request body data as JSON
app.use(express.json());

// Mount routers for specific API endpoints
app.use('/api/cars', carsRouter);
app.use('/api/services', servicesRouter);
app.use('/api/bookings', bookingsRouter);

// Error handling middleware (optional)
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Get port from environment variable or use default
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on port ${port}`));
