const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: 'localhost', // Replace with your MySQL host
  user: 'root', // Replace with your MySQL username
  password: 'password', // Replace with your MySQL password
  database: 'car_service_management', // Replace with your MySQL database name
});

module.exports = pool;
