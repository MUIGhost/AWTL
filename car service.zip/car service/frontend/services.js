// In your services.html or a separate JavaScript file for this page
const carServiceForm = document.getElementById('car-service-form');

carServiceForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const carMake = document.getElementById('car-make').value;
  const carModel = document.getElementById('car-model').value;
  const carYear = document.getElementById('car-year').value;

  const carData = {
    make: carMake,
    model: carModel,
    year: carYear,
  };

  try {
    const response = await fetch('/api/cars', { // Replace with your car creation endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(carData),
    });

    if (response.ok) {
      console.log('Car information saved!');
      // Redirect to service selection page or display success message
      window.location.href = "choose-service.html"; // Optional redirect to services page
    } else {
      const error = await response.text();
      console.error('Error saving car information:', error);
      // Handle errors (e.g., display error message)
      alert('Failed to save car information. Please try again.');
    }
  } catch (error) {
    console.error('Error:', error);
    // Handle unexpected errors
    alert('An error occurred. Please try again.');
  }
});
