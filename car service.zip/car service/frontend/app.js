const mainContent = document.getElementById('main-content');

// Helper function to display error messages (optional)
function displayError(message) {
  const errorElement = document.createElement('div');
  errorElement.classList.add('error-message');
  errorElement.textContent = message;
  mainContent.appendChild(errorElement);
}

// Function to fetch and display cars (existing)
async function getCars() {
  const response = await fetch('/api/cars'); // Replace with your car data endpoint
  const carsData = await response.json();

  // Build HTML elements to display cars (replace with your desired structure)
  let content = '<h2>Cars</h2><ul>';
  for (const car of carsData) {
    content += `<li data-car-id="${car.id}">${car.make} ${car.model}</li>`;
  }
  content += '</ul>';

  mainContent.innerHTML = content;
}

// Function to fetch and display services (existing)
async function getServices() {
  const response = await fetch('/api/services'); // Replace with your service data endpoint
  const servicesData = await response.json();

  // Build HTML elements to display services (replace with your desired structure)
  let content = '<h2>Services</h2><ul>';
  for (const service of servicesData) {
    content += `<li data-service-id="${service.id}">${service.name} (Price: ${service.price})</li>`;
  }
  content += '</ul>';

  mainContent.innerHTML = content;
}

// Function to fetch and display bookings (existing)
async function getBookings() {
  const response = await fetch('/api/bookings'); // Replace with your booking data endpoint
  const bookingsData = await response.json();

  // Build HTML elements to display bookings (replace with your desired structure)
  let content = '<h2>Bookings</h2><table>';
  content += `<tr><th>Customer</th><th>Car</th><th>Service</th><th>Date</th></tr>`;
  for (const booking of bookingsData) {
    content += `<tr>
      <td>${booking.customer_name}</td>
      <td>${booking.car_make} ${booking.car_model}</td>  <td>${booking.service_name}</td>
      <td>${booking.booking_date}</td>
    </tr>`;
  }
  content += '</table>';

  mainContent.innerHTML = content;
}

// Handle navigation clicks
const navLinks = document.querySelectorAll('nav a');
navLinks.forEach(link => {
  link.addEventListener('click', (event) => {
    event.preventDefault();
    const section = event.target.dataset.section;
    switch (section) {
      case 'cars':
        getCars();
        break;
      case 'services':
        getServices();
        break;
      case 'bookings':
        getBookings();
        break;
    }
  });
});
