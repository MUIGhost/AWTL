const form = document.getElementById('add-service-form');

form.addEventListener('submit', async (event) => {
  event.preventDefault(); // Prevent default form submission

  const serviceName = document.getElementById('service-name').value;
  const servicePrice = document.getElementById('service-price').value;

  // Prepare data to send to the backend
  const data = {
    name: serviceName,
    price: servicePrice,
  };

  try {
    const response = await fetch('models/services.js', { // Replace with your service creation endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data),
    });

    if (response.ok) {
      console.log('Service created successfully!');
      // Handle successful service creation (e.g., redirect, display success message)
      alert('Service added successfully!');
      // Optionally, clear the form or redirect to another page
    } else {
      const error = await response.text();
      console.error('Error creating service:', error);
      // Handle errors (e.g., display error message)
      alert('Failed to add service. Please try again.');
    }
  } catch (error) {
    console.error('Error:', error);
    // Handle unexpected errors
    alert('An error occurred. Please try again.');
  }
});
