const form = document.getElementById('add-booking-form');
const carSelect = document.getElementById('car-selection');
const serviceSelect = document.getElementById('service-selection');

// Function to fetch car data and populate the car selection dropdown
async function getCars() {
  const response = await fetch('/api/cars'); // Replace with your car data endpoint
  const carsData = await response.json();

  carsData.forEach(car => {
    const option = document.createElement('option');
    option.value = car.id;
    option.text = `${car.make} ${car.model}`;
    carSelect.appendChild(option);
  });
}

// Function to fetch service data and populate the service selection dropdown
async function getServices() {
  const response = await fetch('/api/services'); // Replace with your service data endpoint
  const servicesData = await response.json();

  servicesData.forEach(service => {
    const option = document.createElement('option');
    option.value = service.id;
    option.text = service.name;
    serviceSelect.appendChild(option);
  });
}

// Call functions to fetch and populate select elements on initial load
getCars();
getServices();

form.addEventListener('submit', async (event) => {
  event.preventDefault(); // Prevent default form submission

  const customerName = document.getElementById('customer-name').value;
  const carId = document.getElementById('car-selection').value;
  const serviceId = document.getElementById('service-selection').value;
  const bookingDate = document.getElementById('booking-date').value;

  // Prepare data to send to the backend
  const data = {
    customer_name: customerName,
    car_id: carId,
    service_id: serviceId,
    booking_date: bookingDate,
  };

  try {
    const response = await fetch('models/bookings.js', { // Replace with your booking creation endpoint
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(data),
    });

    if (response.ok) {
      console.log('Booking created successfully!');
      // Handle successful booking creation (e.g., redirect, display success message)
      alert('Booking added successfully!');
      // Optionally, clear the form or redirect to another page
    } else {
      const error = await response.text();
      console.error('Error creating booking:', error);
      // Handle errors (e.g., display error message)
      alert('Failed to add booking. Please try again.');
    }
  } catch (error) {
    console.error('Error:', error);
    // Handle unexpected errors
    alert('An error occurred. Please try again.');
  }
});
