// server.js
const express = require('express');
const multer = require('multer');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const upload = multer({ dest: 'uploads/' });

// Serve static files from the 'uploads' directory
app.use(express.static(path.join(__dirname, 'uploads')));

// MySQL connection configuration
const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'hospital'
});

// Middleware to parse JSON bodies
app.use(express.json());

// Route to serve HTML file for file uploads
app.get('/upload', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Route to handle form submission
app.post('/submit', (req, res) => {
  // Extract form data from request body
  const formData = req.body;

  // Perform database insertion
  pool.query('INSERT INTO appointments SET ?', formData, (error, results) => {
    if (error) {
      console.error('Error inserting into database:', error);
      return res.status(500).send('Error inserting into database');
    }

    console.log('Inserted into database:', results);
    res.status(200).send('Form submitted successfully');
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
