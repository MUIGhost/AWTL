// About.js
import React from 'react';

const About = () => {
  return (
    <div>
      <h2>About Page</h2>
      <p>Welcome to the Student Management System!</p>
      <p>This system is designed to help manage student information efficiently.</p>
      <p>Features:</p>
      <ul>
        <li>User registration and login</li>
        <li>Profile management</li>
        <li>Course enrollment</li>
        <li>Grades and progress tracking</li>
      </ul>
      <p>Feel free to explore the system and let us know if you have any feedback!</p>
    </div>
  );
};

export default About;
