const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise'); // Assuming you're using mysql2

const app = express();

// Middleware to parse incoming request body
app.use(bodyParser.urlencoded({ extended: false }));

// Database connection details (replace with your actual credentials)
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'aryan'
};

// Connect to the database (can be moved to a separate function for reusability)
async function connectToDatabase() {
  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database successfully!');
    return connection;
  } catch (error) {
    console.error('Error connecting to database:', error);
    throw error; // Re-throw the error to stop server if connection fails
  }
}

// Route to display appointment booking form (GET /)
app.get('/', (req, res) => {
  res.sendFile(__dirname + 'public/index.html'); // Replace with your form HTML file
});

// Route to handle appointment submissions (POST /appointments)
app.post('/appointments', async (req, res) => {
  const name = req.body.name;
  const date = req.body.date;
  const time = req.body.time;
  const email = req.body.email;
  const phone = req.body.phone;

  // Connect to the database
  let connection;
  try {
    connection = await connectToDatabase();
  } catch (error) {
    // Handle connection error gracefully (e.g., display error message to user)
    res.status(500).send('Error connecting to database!');
    return;
  }

  // Prepare and execute SQL query to insert appointment data
  const sql = `
    INSERT INTO appointments (name, date, time, email, phone)
    VALUES (?, ?, ?, ?, ?)
  `;

  try {
    const [results] = await connection.query(sql, [name, date, time, email, phone]);
    console.log('Appointment inserted successfully:', results);
    res.send('Appointment submitted successfully!');
  } catch (error) {
    console.error('Error inserting appointment:', error);
    res.status(500).send('Error submitting appointment!');
  } finally {
    // Close the database connection (optional, connection pool might handle it)
    connection.end();
  }
});

// Start the server
async function startServer() {
  try {
    await connectToDatabase(); // Ensure database connection before starting server
    app.listen(3000, () => console.log('Server listening on port 3000'));
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1); // Exit the process on server error
  }
}

startServer();
