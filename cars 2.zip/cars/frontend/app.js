// app.js

// Function to handle form submission for adding a car
const addCarForm = document.getElementById('add-car-form');
if (addCarForm) {
    addCarForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        const formData = new FormData(addCarForm);
        const carData = {};
        formData.forEach((value, key) => {
            carData[key] = value;
        });

        try {
            const response = await fetch('/api/cars', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(carData)
            });

            if (!response.ok) {
                throw new Error('Failed to add car');
            }

            const data = await response.json();
            console.log('Car added successfully:', data);

            // Redirect or display success message
        } catch (error) {
            console.error('Error adding car:', error);
            // Display error message
        }
    });
}

// Function to handle form submission for adding a service
const addServiceForm = document.getElementById('add-service-form');
if (addServiceForm) {
    addServiceForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        const formData = new FormData(addServiceForm);
        const serviceData = {};
        formData.forEach((value, key) => {
            serviceData[key] = value;
        });

        try {
            const response = await fetch('/api/services', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(serviceData)
            });

            if (!response.ok) {
                throw new Error('Failed to add service');
            }

            const data = await response.json();
            console.log('Service added successfully:', data);

            // Redirect or display success message
        } catch (error) {
            console.error('Error adding service:', error);
            // Display error message
        }
    });
}

// Function to handle form submission for adding an appointment
const addAppointmentForm = document.getElementById('add-appointment-form');
if (addAppointmentForm) {
    addAppointmentForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        
        const formData = new FormData(addAppointmentForm);
        const appointmentData = {};
        formData.forEach((value, key) => {
            appointmentData[key] = value;
        });

        try {
            const response = await fetch('/api/appointments', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(appointmentData)
            });

            if (!response.ok) {
                throw new Error('Failed to add appointment');
            }

            const data = await response.json();
            console.log('Appointment added successfully:', data);

            // Redirect or display success message
        } catch (error) {
            console.error('Error adding appointment:', error);
            // Display error message
        }
    });
}

// Function to fetch and display car details
const displayCarDetails = async (carId) => {
    try {
        const response = await fetch(`/api/cars/${carId}`);
        const data = await response.json();

        // Update DOM with car details
        console.log('Car details:', data);
    } catch (error) {
        console.error('Error fetching car details:', error);
        // Display error message
    }
};

// Function to fetch and display service details
const displayServiceDetails = async (serviceId) => {
    try {
        const response = await fetch(`/api/services/${serviceId}`);
        const data = await response.json();

        // Update DOM with service details
        console.log('Service details:', data);
    } catch (error) {
        console.error('Error fetching service details:', error);
        // Display error message
    }
};

// Function to fetch and display appointment details
const displayAppointmentDetails = async (appointmentId) => {
    try {
        const response = await fetch(`/api/appointments/${appointmentId}`);
        const data = await response.json();

        // Update DOM with appointment details
        console.log('Appointment details:', data);
    } catch (error) {
        console.error('Error fetching appointment details:', error);
        // Display error message
    }
};

// Call function to display car details if needed
const carDetailsElement = document.getElementById('car-details');
if (carDetailsElement) {
    const carId = // Extract car ID from URL or other source
    displayCarDetails(carId);
}

// Call function to display service details if needed
const serviceDetailsElement = document.getElementById('service-details');
if (serviceDetailsElement) {
    const serviceId = // Extract service ID from URL or other source
    displayServiceDetails(serviceId);
}

// Call function to display appointment details if needed
const appointmentDetailsElement = document.getElementById('appointment-details');
if (appointmentDetailsElement) {
    const appointmentId = // Extract appointment ID from URL or other source
    displayAppointmentDetails(appointmentId);
}
