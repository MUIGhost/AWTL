const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'frontend'))); // Serve static files from the "frontend" directory

const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'cars'
};

async function connectToDatabase() {
  try {
    const connection = await mysql.createConnection(dbConfig);
    console.log('Connected to database successfully!');
    return connection;
  } catch (error) {
    console.error('Error connecting to database:', error);
    throw error;
  }
}

async function executeQuery(sql, params = []) {
  let connection;
  try {
    connection = await connectToDatabase();
    const [results] = await connection.query(sql, params);
    return results;
  } catch (error) {
    console.error('Error executing query:', error);
    throw error;
  } finally {
    if (connection) connection.end();
  }
}

// CRUD operations for cars table
async function addCar(car) {
  const { make, model, year, licensePlate, customerId } = car;
  const sql = `
    INSERT INTO cars (make, model, year, license_plate)
    VALUES (?, ?, ?, ?)
  `;
  const results = await executeQuery(sql, [make, model, year, licensePlate, customerId]);
  console.log('Car added successfully:', results);
  return results.insertId;
}

async function getCarById(id) {
  const sql = `SELECT * FROM cars WHERE car_id = ?`;
  const results = await executeQuery(sql, [id]);
  return results[0];
}

// CRUD operations for services table
async function addService(service) {
  const { name, description, price } = service;
  const sql = `
    INSERT INTO services (name, description, price)
    VALUES (?, ?, ?)
  `;
  const results = await executeQuery(sql, [name, description, price]);
  console.log('Service added successfully:', results);
  return results.insertId;
}

async function getServiceById(id) {
  const sql = `SELECT * FROM services WHERE service_id = ?`;
  const results = await executeQuery(sql, [id]);
  return results[0];
}

// CRUD operations for appointments table
async function addAppointment(appointment) {
  const { name, date, time, email, phone, carId, serviceId } = appointment;
  const sql = `
    INSERT INTO appointments (name, date, time, email, phone, car_id, service_id)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;
  const results = await executeQuery(sql, [name, date, time, email, phone, carId, serviceId]);
  console.log('Appointment added successfully:', results);
  return results.insertId;
}

async function getAppointmentById(id) {
  const sql = `SELECT * FROM appointments WHERE appointment_id = '1';
  `;
  const results = await executeQuery(sql, [id]);
  return results[0];
}

// Routes for cars
app.get('/cars/add', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'add-car.html')); // Render a form to add a new car
});

app.post('/cars/add', async (req, res) => {
  try {
    const { make, model, year, licensePlate, customerId } = req.body;
    const car = { make, model, year, licensePlate, customerId };
    const newCarId = await addCar(car);
    res.redirect(`/cars/${newCarId}`);
  } catch (error) {
    console.error('Error adding car:', error);
    res.status(500).send('An error occurred while adding the car.');
  }
});

app.get('/cars/:id', async (req, res) => {
  try {
    const carId = req.params.id;
    const car = await getCarById(carId);
    if (!car) {
      res.status(404).send('Car not found');
    } else {
      res.sendFile(path.join(__dirname, 'frontend', 'car-details.html'));
    }
  } catch (error) {
    console.error('Error fetching car details:', error);
    res.status(500).send('An error occurred while fetching car details.');
  }
});

// Routes for services
app.get('/services/add', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'add-service.html')); // Render a form to add a new service
});

app.post('/services/add', async (req, res) => {
  try {
    const { name, description, price } = req.body;
    const service = { name, description, price };
    const newServiceId = await addService(service);
    res.redirect(`/services/${newServiceId}`);
  } catch (error) {
    console.error('Error adding service:', error);
    res.status(500).send('An error occurred while adding the service.');
  }
});

app.get('/services/:id', async (req, res) => {
  try {
    const serviceId = req.params.id;
    const service = await getServiceById(serviceId);
    if (!service) {
      res.status(404).send('Service not found');
    } else {
      res.sendFile(path.join(__dirname, 'frontend', 'service-details.html'));
    }
  } catch (error) {
    console.error('Error fetching service details:', error);
    res.status(500).send('An error occurred while fetching service details.');
  }
});

// Routes for appointments
app.get('/appointments/add', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'add-appointment.html')); // Render a form to add a new appointment
});

app.post('/appointments/add', async (req, res) => {
  try {
    const { name, date, time, email, phone, carId, serviceId } = req.body;
    const appointment = { name, date, time, email, phone, carId, serviceId };
    const newAppointmentId = await addAppointment(appointment);
    res.redirect(`/appointments/${newAppointmentId}`);
  } catch (error) {
    console.error('Error adding appointment:', error);
    res.status(500).send('An error occurred while adding the appointment.');
  }
});

app.get('/appointments/:id', async (req, res) => {
  try {
    const appointmentId = req.params.id;
    const appointment = await getAppointmentById(appointmentId);
    if (!appointment) {
      res.status(404).send('Appointment not found');
    } else {
      res.sendFile(path.join(__dirname, 'frontend', 'appointment-details.html'));
    }
  } catch (error) {
    console.error('Error fetching appointment details:', error);
    res.status(500).send('An error occurred while fetching appointment details.');
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
});
