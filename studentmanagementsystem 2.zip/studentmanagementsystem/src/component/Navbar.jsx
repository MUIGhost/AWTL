import { Link } from "react-router-dom"



const Navbar=()=>{
    return(
       <>
          <nav style={{display:'flex',justifyContent:'space-evenly',alignItems:'center'}} className="nav">
            {/* <div className="nav_logo">
               Navbar logo
            </div> */}
            <div style={{}}>
               <ul className="nav-list" style={{display:'flex',textDecoration:'none',listStyle:'none'}}>
                <li><Link to='/'>Home</Link></li>
                <li><Link to='/signup'>SignUp</Link></li>
                <li><Link to='/signin'>SignIn</Link></li>
                <li><Link to='/about'>About</Link></li>
                <li><Link to='/contact'>Contact</Link></li>
               </ul>
            </div>
          </nav>
       </>
    )
}

export default Navbar