
import React, { useState } from 'react';

const SignIn=()=>{
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
  
    const handleLogin = () => {
      if (username === 'admin' && password === 'password') {
        // Login successful, you can redirect the user to another page
        console.log('Login successful');
      } else {
        setError('Invalid username or password');
      }
    };
    return(
        <div className='main-container'>
        <div className="form-container">
      <h2>Login Page</h2>
      <form>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="input-field"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input-field"
          />
        </div>
        <button type="button" onClick={handleLogin} className="login-button">
          Login
        </button>
        {error && <div className="error-message">{error}</div>}
      </form>
    </div>
    </div>
    )
}

export default SignIn