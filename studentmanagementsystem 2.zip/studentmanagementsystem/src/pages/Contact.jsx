
import React, { useState } from 'react';

const Contact=()=>{
  
    return(
      <div>
      <header>
      <h1>Contact Us</h1>
      <p>Have questions or feedback? Get in touch with us!</p>
    </header>
  
    <main>
    <div className="form-container">
    <form>
        <div className="form-group">
          <label htmlFor="username">Name</label>
          <input
            type="text"
            id="username"
            className="input-field"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Email</label>
          <input
            type="password"
            id="password"
            className="input-field"
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Message</label>
          <input
            type="password"
            id="password"
            className="input-field"
          />
        </div>
        <button type="button" className="login-button">
          Send Message
        </button>
      </form>
      </div>
    </main>
  
    <footer>
      <p>&copy; 2024 Student Management System</p>
    </footer>
    </div>
    )
}

export default Contact