


const Home=()=>{
    return(
       <>
        <header>
    <h1>Welcome to the Student Management System</h1>
    <p>Efficiently manage student information and activities.</p>
  </header>

  <main>
  <div className="form-container">
    <section class="features">
      <h2>Features</h2>
      <ul>
        <li>User Registration and Login</li>
        <li>Profile Management</li>
        <li>Course Enrollment</li>
        <li>Grades and Progress Tracking</li>
      </ul>
    </section>
    </div>
  </main>

  <footer>
    <p>&copy; 2024 Student Management System</p>
  </footer>
       </>
    )
}

export default Home