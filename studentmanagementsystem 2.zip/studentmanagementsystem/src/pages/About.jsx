


const About=()=>{
    return(
        <>
    <div>
    <header>
    <h1>About Us</h1>
  </header>

  <main>
  <div className="form-container">
  <form>
  <p className="about-text">This system is designed to help manage student information efficiently.</p>
  <p>The Student Management System is designed to help educational institutions manage student information and activities in a streamlined manner.</p>
      <p>Our goal is to provide an efficient platform for administrators, teachers, and students to interact and collaborate.</p>
   
      <p className="about-text">Feel free to explore the system and let us know if you have any feedback!</p>
   
     
    </form>
    </div>
  </main>

  <footer>
    <p>&copy; 2024 Student Management System</p>
  </footer>
  </div>
  </>
    )
}

export default About