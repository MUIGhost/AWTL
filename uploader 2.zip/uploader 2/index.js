// index.js
const express = require('express');
const multer = require('multer');
const mysql = require('mysql2');

const app = express();
const upload = multer({ dest: 'uploads/' });
const path = require('path');
app.use(express.static(path.join(__dirname, 'uploads')));

// MySQL connection configuration
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'node'
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// Route to handle file uploads
app.post('/upload', upload.single('file'), (req, res) => {
  const { filename, path, originalname } = req.file; // Capture original filename

  // Insert file metadata into MySQL database
// Insert file metadata into MySQL database
const sql = 'INSERT INTO files (filename, filepath, originalname) VALUES (?, ?, ?)'; // Include originalname in SQL query
connection.query(sql, [filename, path, originalname], (err, result) => {
  if (err) {
    console.error('Error uploading file:', err);
    res.status(500).json({ success: false, message: 'Error uploading file' });
  } else {
    res.sendFile('uploads/sucess.html' , { root : __dirname});
  }
});


});

// Route to retrieve file metadata from MySQL
app.get('/files', (req, res) => {
  // Retrieve file metadata from MySQL
  const sql = 'SELECT * FROM files';
  connection.query(sql, (err, results) => {
    if (err) {
      console.error('Error retrieving files:', err);
      res.status(500).send('Error retrieving files');
    } else {
      res.json(results);
    }
  });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
