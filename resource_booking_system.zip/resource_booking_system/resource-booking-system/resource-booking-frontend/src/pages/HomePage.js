// src/pages/HomePage.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ResourceList from '../components/ResourceList';

const HomePage = () => {
  const [resources, setResources] = useState([]);

  useEffect(() => {
    // Fetch resources from the backend API
    const fetchResources = async () => {
      try {
        const response = await axios.get('/api/resources');
        setResources(response.data);
      } catch (error) {
        console.error('Error fetching resources:', error);
      }
    };

    fetchResources();
  }, []);

  return (
    <div>
      <h1>Resource Booking System</h1>
      <ResourceList resources={resources} />
    </div>
  );
};

export default HomePage;
