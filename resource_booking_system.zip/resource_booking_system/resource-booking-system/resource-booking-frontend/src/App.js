import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Import Routes
import { AuthProvider } from './context/AuthContext';
import HomePage from './pages/HomePage';
import BookingPage from './pages/BookingPage';
import LoginPage from './components/Login';
import PrivateRoute from './components/PrivateRoute';

const App = () => {
  return (
    <Router>
      <AuthProvider>
        <div>
          <Routes> {/* Use Routes component */}
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<LoginPage />} />
            <PrivateRoute path="/booking" element={<BookingPage />} />
            {/* Add more protected routes as needed */}
          </Routes>
        </div>
      </AuthProvider>
    </Router>
  );
};

export default App;
