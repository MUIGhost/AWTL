// src/components/BookingForm.js

import React, { useState } from 'react';
import axios from 'axios';

const BookingForm = () => {
  const [resourceId, setResourceId] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Send booking request to the backend API
      const response = await axios.post('/api/bookings', {
        resource_id: resourceId,
        start_time: startTime,
        end_time: endTime,
      });

      console.log('Booking created:', response.data);
      // Optionally, you can redirect the user to a confirmation page or display a success message
    } catch (error) {
      console.error('Error creating booking:', error);
      // Optionally, you can display an error message to the user
    }
  };

  return (
    <div>
      <h2>Book a Resource</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="resource">Resource:</label>
          <select id="resource" value={resourceId} onChange={(e) => setResourceId(e.target.value)} required>
            <option value="">Select a resource</option>
            {/* Render options dynamically based on resources fetched from backend */}
          </select>
        </div>
        <div>
          <label htmlFor="startTime">Start Time:</label>
          <input type="datetime-local" id="startTime" value={startTime} onChange={(e) => setStartTime(e.target.value)} required />
        </div>
        <div>
          <label htmlFor="endTime">End Time:</label>
          <input type="datetime-local" id="endTime" value={endTime} onChange={(e) => setEndTime(e.target.value)} required />
        </div>
        <button type="submit">Book Resource</button>
      </form>
    </div>
  );
};

export default BookingForm;
