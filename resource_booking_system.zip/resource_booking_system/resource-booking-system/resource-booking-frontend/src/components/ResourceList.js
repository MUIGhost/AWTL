// src/components/ResourceList.js

import React from 'react';

const ResourceList = ({ resources }) => {
  return (
    <div>
      <h2>Available Resources</h2>
      <ul>
        {resources.map(resource => (
          <li key={resource.id}>
            <strong>{resource.name}</strong> - {resource.description} (Capacity: {resource.capacity})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ResourceList;
