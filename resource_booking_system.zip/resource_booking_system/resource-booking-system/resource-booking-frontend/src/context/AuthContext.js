// src/context/AuthContext.js

import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';

// Create Auth Context
const AuthContext = createContext();

// Custom hook to use Auth Context
export const useAuth = () => useContext(AuthContext);

// Auth Provider component
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Function to log in user
  const login = async (credentials) => {
    try {
      const response = await axios.post('/api/auth/login', credentials);
      setUser(response.data.user);
      // Store token in browser storage (e.g., localStorage)
      localStorage.setItem('token', response.data.token);
    } catch (error) {
      console.error('Error logging in:', error);
      throw new Error('Failed to log in');
    }
  };

  // Function to log out user
  const logout = () => {
    // Remove token from browser storage
    localStorage.removeItem('token');
    setUser(null);
  };

  // Function to check if user is authenticated
  const isAuthenticated = () => !!user;

  useEffect(() => {
    // Check if user is already logged in (e.g., token exists in storage)
    const token = localStorage.getItem('token');
    if (token) {
      // Fetch user data from backend using token
      const fetchUser = async () => {
        try {
          const response = await axios.get('/api/auth/user', {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          });
          setUser(response.data);
        } catch (error) {
          console.error('Error fetching user:', error);
          // Clear token and log out user if token is invalid
          localStorage.removeItem('token');
          setUser(null);
        } finally {
          setLoading(false);
        }
      };

      fetchUser();
    } else {
      setLoading(false);
    }
  }, []);

  const value = {
    user,
    login,
    logout,
    isAuthenticated,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
