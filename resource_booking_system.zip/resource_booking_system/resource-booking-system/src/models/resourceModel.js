// src/models/resourceModel.js

const db = require('../db');

// Resource model
class Resource {
    constructor(name, description, capacity) {
        this.name = name;
        this.description = description;
        this.capacity = capacity;
    }

    // Create a new resource
    static create(newResource, callback) {
        db.query('INSERT INTO resources SET ?', newResource, (err, result) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, result.insertId);
        });
    }

    // Get all resources
    static getAll(callback) {
        db.query('SELECT * FROM resources', (err, results) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, results);
        });
    }

    // Get resource by ID
    static getById(id, callback) {
        db.query('SELECT * FROM resources WHERE id = ?', [id], (err, results) => {
            if (err) {
                return callback(err, null);
            }
            if (results.length === 0) {
                return callback(null, null);
            }
            callback(null, results[0]);
        });
    }

    // Update resource by ID
    static updateById(id, updatedResource, callback) {
        db.query('UPDATE resources SET ? WHERE id = ?', [updatedResource, id], (err, result) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, result.changedRows);
        });
    }

    // Delete resource by ID
    static deleteById(id, callback) {
        db.query('DELETE FROM resources WHERE id = ?', [id], (err, result) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, result.affectedRows);
        });
    }
}

module.exports = Resource;
