// src/models/userModel.js

const db = require('../db');

// User model
class User {
    constructor(username, password) {
        this.username = username;
        this.password = password;
    }

    // Create a new user
    static create(newUser, callback) {
        db.query('INSERT INTO users SET ?', newUser, (err, result) => {
            if (err) {
                return callback(err, null);
            }
            callback(null, result.insertId);
        });
    }

    // Find a user by username
    static findByUsername(username, callback) {
        db.query('SELECT * FROM users WHERE username = ?', [username], (err, result) => {
            if (err) {
                return callback(err, null);
            }
            if (result.length) {
                const user = result[0];
                return callback(null, user);
            }
            callback(null, null); // User not found
        });
    }
}

module.exports = User;
