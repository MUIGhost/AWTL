// src/routes/resourceRoutes.js

const express = require('express');
const router = express.Router();
const resourceController = require('../controllers/resourceController');

// Resource routes
router.post('/resources', resourceController.createResource);
router.get('/resources', resourceController.getAllResources);
router.get('/resources/:id', resourceController.getResourceById);
router.put('/resources/:id', resourceController.updateResourceById);
router.delete('/resources/:id', resourceController.deleteResourceById);

module.exports = router;
