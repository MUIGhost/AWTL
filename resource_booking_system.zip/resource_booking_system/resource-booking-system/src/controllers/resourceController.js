// src/controllers/resourceController.js

const Resource = require('../models/resourceModel');

// Controller functions
const resourceController = {
    // Create a new resource
    createResource: (req, res) => {
        const { name, description, capacity } = req.body;
        const newResource = new Resource(name, description, capacity);

        Resource.create(newResource, (err, resourceId) => {
            if (err) {
                console.error('Error creating resource:', err);
                return res.status(500).json({ error: 'Error creating resource' });
            }
            res.status(201).json({ message: 'Resource created successfully', resourceId });
        });
    },

    // Get all resources
    getAllResources: (req, res) => {
        Resource.getAll((err, resources) => {
            if (err) {
                console.error('Error getting resources:', err);
                return res.status(500).json({ error: 'Error getting resources' });
            }
            res.status(200).json(resources);
        });
    },

    // Get resource by ID
    getResourceById: (req, res) => {
        const resourceId = req.params.id;

        Resource.getById(resourceId, (err, resource) => {
            if (err) {
                console.error('Error getting resource:', err);
                return res.status(500).json({ error: 'Error getting resource' });
            }
            if (!resource) {
                return res.status(404).json({ error: 'Resource not found' });
            }
            res.status(200).json(resource);
        });
    },

    // Update resource by ID
    updateResourceById: (req, res) => {
        const resourceId = req.params.id;
        const updatedResource = req.body;

        Resource.updateById(resourceId, updatedResource, (err, rowsAffected) => {
            if (err) {
                console.error('Error updating resource:', err);
                return res.status(500).json({ error: 'Error updating resource' });
            }
            if (rowsAffected === 0) {
                return res.status(404).json({ error: 'Resource not found' });
            }
            res.status(200).json({ message: 'Resource updated successfully' });
        });
    },

    // Delete resource by ID
    deleteResourceById: (req, res) => {
        const resourceId = req.params.id;

        Resource.deleteById(resourceId, (err, rowsAffected) => {
            if (err) {
                console.error('Error deleting resource:', err);
                return res.status(500).json({ error: 'Error deleting resource' });
            }
            if (rowsAffected === 0) {
                return res.status(404).json({ error: 'Resource not found' });
            }
            res.status(200).json({ message: 'Resource deleted successfully' });
        });
    }
};

module.exports = resourceController;
