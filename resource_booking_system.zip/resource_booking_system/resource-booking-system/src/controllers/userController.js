// src/controllers/userController.js

const User = require('../models/userModel');

// Controller functions
const userController = {
    // Create a new user
    createUser: (req, res) => {
        const { username, password } = req.body;
        const newUser = new User(username, password);

        User.create(newUser, (err, userId) => {
            if (err) {
                console.error('Error creating user:', err);
                return res.status(500).json({ error: 'Error creating user' });
            }
            res.status(201).json({ message: 'User created successfully', userId });
        });
    },

    // Get user by username
    getUserByUsername: (req, res) => {
        const { username } = req.params;

        User.findByUsername(username, (err, user) => {
            if (err) {
                console.error('Error finding user:', err);
                return res.status(500).json({ error: 'Error finding user' });
            }
            if (!user) {
                return res.status(404).json({ error: 'User not found' });
            }
            res.status(200).json(user);
        });
    }
};

module.exports = userController;
